import pygame
import tkinter
import cardsanddeck
#from tkinter import messagebox


#Defines colors to be used easily so you can call them by name
white = (255, 255, 255)
black = (0, 0, 0)
red = (200, 0, 0)
green = (0, 200, 0)
blue = (0, 0, 255)
bright_green = (0, 255, 0)
bright_red = (255, 0, 0)
light_blue = (173, 216, 230)

window = tkinter.Tk()

screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()
window.wm_withdraw()
#This locks in the size of the window as 3/4 of your screen size, so it will never take up the full screen.
display_width_pre = int(screen_width)/1.25
display_height_pre = int(screen_height)/1.25
display_width = int(display_width_pre)
display_height = int(display_height_pre)


screen = pygame.display.set_mode((display_height,display_width))

clock = pygame.time.Clock()
#Creates the canvas of the game, sets the size. This is the surface
gameDisplay = pygame.display.set_mode((display_width,display_height))
#Or display.flip(), which updates the entire surface at once. Whereas upda

#A small simple function that facilitates printing text
def text_objects(text, font):
	textSurface = font.render(text, True, black)
	return textSurface, textSurface.get_rect()

#This function defines the buttons for the main menu and eventually the game itself. x, y, w, and h are the position and size of the button, and the on/offcolor decide the color when the mouse is touching the button.
def button(message,x,y,w,h,offColor,onColor,action=None):
	mouse = pygame.mouse.get_pos()
	click = pygame.mouse.get_pressed()
	#print(click)
	#Draws a specific rectangle if the mouse is there
	if x+w > mouse[0] > x and y+h > mouse[1] > y:
		pygame.draw.rect(gameDisplay, onColor,(x,y,w,h))

		if click[0] == 1 and action != None:
			action()
	#Draws a different rectangle if it isn't         
	else:
		pygame.draw.rect(gameDisplay, offColor,(x,y,w,h))

	smallText = pygame.font.SysFont("freesansbold.ttf",20)
	textSurf, textRect = text_objects(message, smallText)
	textRect.center = ( (x+(w/2)), (y+(h/2)) )
	gameDisplay.blit(textSurf, textRect)






#Pop-up is for the main menu. It is a function that is used to open a text box, mostly for the instructions option on the main menu.
		 
	

def popup():

	
	#This line is important! Without it, a grey box opens up and is just there, blocking some of the screen and causing some problems.
	window.wm_withdraw()

	#messagebox.showinfo(title="Instructions", message= "Texas HoldEm is the most popular variation of poker. In Texas HoldEm, each player is dealt 2 cards, commonly referred to as the hole cards, and they have to make the best hand from 5 of the 7 that are dealt (5 additional cards are dealt later in the round).\n\nAfter all players have been dealt in, a round of betting occurs. If you believe that your hand is good enough to continue to the next round of betting, you can call the required amount. If no one has raised, the required amount is the big blind. If a previous player has raised, the required amount to call is the size of that player's bet. If you don't believe that your hand is good, then you can Fold your hand. This means that you forfeit your opportunity of winning the pot in exchange for not having to bet. It is recommended to fold weak hands such as a 2 and a 7 with mismatched suits. You can also raise, or bet an amount that is higher than the required minimum bet. This will also increase the required amount to call for all players. This is recommended only with strong hands, or if you have a decent hand and you want to push people who are calling with weak hands out of the round. Lastly, a player may also all in, or bet all of their chips. If their stash of chips is larger than anyone who calls, the player who all-ined receives the difference in chips back. \n\nAfter the initial round of betting, three cards are dealt to the community board. These first three cards are called the flop. After the flop, every player can opt to check, which is essentially a ree bet. If every player who had not folded pre-flop checks, the next card is dealt. However, if a player bets a certain amount, every player who wishes to have a chance of winning the pot must call. Like the pre-flop, a player may also fold or all in, but it is not advisable to fold if you are able to check. \n\nAfter this betting round is complete, the same process occurs after the fourth card (the turn) is dealt, and finally, after the fifth and last card (the river) is dealt.After post-river betting has concluded, the remaining players flip their cards and the winner takes the pot. If several players have the same winning hand, the pot is split amongst them.")

class Background(pygame.sprite.Sprite):
	def __init__(self, image_file, location):
		pygame.sprite.Sprite.__init__(self)  #call Sprite initializer
		self.image = pygame.image.load(image_file)
		self.rect = self.image.get_rect()
		self.rect.left, self.rect.top = location

	def nameConvert(self, title):
		answer = False
		if title == '2c':
			answer = pygame.image.load('2_of_clubs.png')
		elif title == '2d':
			answer = pygame.image.load('2_of_diamonds.png')
		elif title == '2h':
			answer = pygame.image.load('2_of_hearts.png')
		elif title == '2s':
			answer = pygame.image.load('2_of_spades.png')
		elif title == '3c':
			answer = pygame.image.load('3_of_clubs.png')
		elif title == '3d':
			answer = pygame.image.load('3_of_diamonds.png')
		elif title == '3h':
			answer = pygame.image.load('3_of_hearts.png')
		elif title == '3s':
			answer = pygame.image.load('3_of_spades.png')
		elif title == '4c':
			answer = pygame.image.load('4_of_clubs.png')
		elif title == '4d':

			answer = pygame.image.load('4_of_diamonds.png')
		elif title == '4h':
			answer = pygame.image.load('4_of_hearts.png')
		elif title == '4s':
			answer = pygame.image.load('4_of_spades.png')
		elif title == '5c':
			answer = pygame.image.load('5_of_clubs.png')
		elif title == '5d':
			answer = pygame.image.load('5_of_diamonds.png')
		elif title == '5h':
			answer = pygame.image.load('5_of_hearts.png')
		elif title == '5s':
			answer = pygame.image.load('5_of_spades.png')
		elif title == '6c':
			answer = pygame.image.load('6_of_clubs.png')
		elif title == '6d':
			answer = pygame.image.load('6_of_diamonds.png')
		elif title == '6h':
			answer = pygame.image.load('6_of_hearts.png')
		elif title == '6s':
			answer = pygame.image.load('6_of_spades.png')
		elif title == '7c':
			answer = pygame.image.load('7_of_clubs.png')
		elif title == '7d':
			answer = pygame.image.load('7_of_diamonds.png')
		elif title == '7h':
			answer = pygame.image.load('7_of_hearts.png')
		elif title == '7s':
			answer = pygame.image.load('7_of_spades.png')
		elif title == '8c':
			answer = pygame.image.load('8_of_clubs.png')
		elif title == '8d':
			answer = pygame.image.load('8_of_diamonds.png')
		elif title == '8h':
			answer = pygame.image.load('8_of_hearts.png')
		elif title == '8s':
			answer = pygame.image.load('8_of_spades.png')
		elif title == '9c':
			answer = pygame.image.load('9_of_clubs.png')
		elif title == '9d':
			answer = pygame.image.load('9_of_diamonds.png')
		elif title == '9h':
			answer = pygame.image.load('9_of_hearts.png')
		elif title == '9s':
			answer = pygame.image.load('9_of_spades.png')
		elif title == 'Tc':
			answer = pygame.image.load('10_of_clubs.png')
		elif title == 'Td':
			answer = pygame.image.load('10_of_diamonds.png')
		elif title == 'Th':
			answer = pygame.image.load('10_of_hearts.png')
		elif title == 'Ts':
			answer = pygame.image.load('10_of_spades.png')
		elif title == 'Qc':
			answer = pygame.image.load('queen_of_clubs.png')
		elif title == 'Qd':
			answer = pygame.image.load('queen_of_diamonds.png')
		elif title == 'Qh':
			answer = pygame.image.load('queen_of_hearts.png')
		elif title == 'Qs':
			answer = pygame.image.load('queen_of_spades.png')
		elif title == 'Jc':
			answer =  pygame.image.load('jack_of_clubs.png')
		elif title == 'Jd':
			answer = pygame.image.load('jack_of_diamonds.png')
		elif title == 'Jh':
			answer = pygame.image.load('jack_of_hearts.png')
		elif title == 'Js':
			answer = pygame.image.load('jack_of_spades.png')
		elif title == 'Kc':
			answer = pygame.image.load('king_of_clubs.png')
		elif title == 'Kd':
			answer = pygame.image.load('king_of_diamonds.png')
		elif title == 'Kh':
			answer = pygame.image.load('king_of_hearts.png')
		elif title == 'Ks':
			answer = pygame.image.load('king_of_spades.png')
		elif title == 'back':
			answer = pygame.image.load('playing_card_back.jpg')
		   
		elif title == 'Ac':
			answer = pygame.image.load('ace_of_clubs.png')
		elif title == 'Ad':
			answer = pygame.image.load('ace_of_diamonds.png')
		elif title == 'Ah':
			answer = pygame.image.load('ace_of_hearts.png')
		elif title == 'As':
			answer = pygame.image.load('ace_of_spades.png')
		elif(answer == False):
			raise Exception(title)
		return answer


def hands():
	BackGround = Background('poker_hands.png', [0,0])
	screen.fill([255, 255, 255])
	screen.blit(BackGround.image, BackGround.rect)       

class card_visuals:

	def __init__(self):
		pass
	def show_hand(self):
		deck = cardsanddeck.Deck()
		BackGround = Background('poker_background.png', [0,0])
		mycards = cardsanddeck.Deck.dealPlayer1(deck)
		mycard1 = mycards[0] + mycards[1]
		mycard2 = mycards[2] + mycards[3]
		print(mycard1)
		print(mycard2)
		image1 = Background.nameConvert(BackGround,str(mycard1))
		image2 = Background.nameConvert(BackGround,str(mycard2))


		showback = 'back'
		cardofback = Background.nameConvert(BackGround,str(showback))
		cardback = pygame.transform.scale(cardofback, (75,116))
		cardback_community = pygame.transform.scale(cardofback, (85,123))
		#This transforms the first hand card image to the proper size, and then implements it into the bottom corner.
		new_image_file = pygame.transform.scale(image1, (100,145))
		gameDisplay.blit(new_image_file, [(display_width - 100),(display_height - 145)])
		#This transforms the second hand card, puts it next to the first card
		new_image_file2 = pygame.transform.scale(image2, (100,145))
		gameDisplay.blit(new_image_file2, [(display_width - 200),(display_height - 145)])
		#This transforms the first flop card and puts it in the center of the table
		gameDisplay.blit(cardback_community, [(display_width/2)-200,(display_height/2)])
		gameDisplay.blit(cardback_community, [(display_width/2)-100,(display_height/2)])
		gameDisplay.blit(cardback_community, [(display_width/2)-300,(display_height/2)])

		gameDisplay.blit(cardback, [(75),(display_height/3)])
		gameDisplay.blit(cardback, [((display_width)-(display_width - 1)),(display_height/3)])

		gameDisplay.blit(cardback, [(175),(display_height - (display_height - 1))])
		gameDisplay.blit(cardback, [(100),(display_height - (display_height - 1))])

		gameDisplay.blit(cardback, [(display_width - 275),(display_height - (display_height - 1))])
		gameDisplay.blit(cardback, [(display_width - 200),(display_height - (display_height - 1))])

		gameDisplay.blit(cardback, [(display_width - 175),(display_height/3)])
		gameDisplay.blit(cardback, [(display_width - 100),(display_height/3)])
		pygame.display.update()

	def postflop(self):
		deck = cardsanddeck.Deck()
		BackGround = Background('poker_background.png', [0,0])
		createflop = cardsanddeck.Deck.dealFlop(deck)
		flop = cardsanddeck.Deck.flopList(deck)
		#flop_firstcard = cardsanddeck.Deck.dealFlop(deck)
		flop_firstcard = Background.nameConvert(BackGround,str(flop[0]))
		flop_secondcard = Background.nameConvert(BackGround,str(flop[1]))
		flop_thirdcard = Background.nameConvert(BackGround,str(flop[2]))

		flop_firstcard_image = pygame.transform.scale(flop_firstcard, (85, 123))
		gameDisplay.blit(flop_firstcard_image,[(display_width/2)-200,(display_height/2)])

		flop_secondcard_image = pygame.transform.scale(flop_secondcard, (85, 123))
		gameDisplay.blit(flop_secondcard_image,[(display_width/2)-100,(display_height/2)])

		flop_thirdcard_image = pygame.transform.scale(flop_thirdcard, (85, 123))
		gameDisplay.blit(flop_thirdcard_image,[(display_width/2)-300,(display_height/2)])
		pygame.display.update()
	def postturn(self):
		BackGround = Background('poker_background.png', [0,0])
		deck = cardsanddeck.Deck()
		turn_card = cardsanddeck.Deck.dealTurn(deck)
		turn_first_card = Background.nameConvert(BackGround,str(turn_card))
		turn_image = pygame.transform.scale(turn_first_card, (85,123))
		gameDisplay.blit(turn_image,[(display_width/2),(display_height/2)])
		pygame.display.update()
	def postriver(self):
		deck = cardsanddeck.Deck()
		BackGround = Background('poker_background.png', [0,0])
		river_card = cardsanddeck.Deck.dealRiver(deck)
		river_first_card = Background.nameConvert(BackGround,str(river_card))
		river_image = pygame.transform.scale(river_first_card, (85,123))
		gameDisplay.blit(river_image,[(display_width/2)+100,(display_height/2)])
		pygame.display.update()
class Menu:
		
		
	def __init__(self, gameDisplay, display_width, display_height, gameLoop):
	 
		intro = True
		#BackGround = Background(image, [0,0])
		pygame.display.update()

		while intro: 

		  
			for event in pygame.event.get():
				#print(event)
				if event.type == pygame.QUIT:
					pygame.quit()
					quit()
			gameDisplay.fill(light_blue)
			#This makes it easier to call title text
			largeText = pygame.font.Font('freesansbold.ttf', 100)
				#These three lines define and display the title
			TextSurf, TextRect = text_objects("Texas Hold 'Em", largeText)
			TextRect.center = ((display_width/2), (display_height/2))
			gameDisplay.blit(TextSurf, TextRect)

			#Defines what the mouse's position is in an easy variable
			mouse = pygame.mouse.get_pos()
			#If the mouse's position is inside the green button, it becomes bright green. Otherwise it stays green. Same concept with red.
			  


				#These are the four buttons displayed on the main menu
			button("Play",display_width/5,(4 * display_height)/5,100,50,green,bright_green,gameLoop)
			button("How to",(2 * display_width)/5,(4 * display_height)/5,100,50,red,bright_red,popup)
			button("High Scores",(3 * display_width)/5,(4 * display_height)/5,100,50,green,bright_green,gameLoop)
			button("Hands",(4 * display_width)/5,(4 * display_height)/5,100,50,red,bright_red,hands)

			pygame.display.update()

			#These two lines down here constantly refresh the visuals
			pygame.display.update()

			clock.tick(15)
		#Just sets up a background using an image file
def main():
	mooga = card_visuals()
	card_visuals.show_hand(mooga)
main()