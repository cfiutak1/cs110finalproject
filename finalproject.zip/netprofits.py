class netprofits:
	def addProfit(self, victory):
		self.P1Stash = open('stash.txt', 'a')
		if(victory == True):
			self.P1Stash.write("40000\n")
			self.P1Stash.close
		if(victory == False):
			self.P1Stash.write("-10000\n")
			self.P1Stash.close
		P1StashTotal = open('stash.txt', 'r')
		total = 10000
		for line in P1StashTotal:
			total += int(line)
		return total
