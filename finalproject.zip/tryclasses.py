import pygame
import time
import random
import tkMessageBox
import Tkinter
import gui
import cardsanddeck
import pickle
import eztext
import ScrolledText


window = Tkinter.Tk()



def userinput():
  moogle = True
  while moogle:
	  events = pygame.event.get()
	  txtbx = eztext.Input(maxlength=45, color=(255,0,0), prompt='Enter your username: ')
	  txtbx.update(events)
	  txtbx.draw(screen)
	  pygame.display.update()
	  for event in pygame.event.get():
			       
		  if event.type == pygame.K_RETURN:
		     gameLoop()

#Creates the canvas of the game, sets the size. This is the surface
gameDisplay = pygame.display.set_mode((display_width,display_height))
#Or display.flip(), which updates the entire surface at once. Whereas update updates a single section, but if there are no parameters it updates the entire thing
#Sets a title
pygame.display.set_caption('Poker Boys 1964')

#pygame.display.update()

#the above is what allows the game to run

#Defines FPS, how fast you see the objects move
clock = pygame.time.Clock()
#Determines block size and allows you to quickly change it!
block_size = 10
#Allows for quick change of Frames per second
FPS = 30
#Defines font using pygame
font = pygame.font.SysFont(None, 25)

#def nameConvert(title):
     


#Function to print a message and it's color
def message_to_screen(msg, color):
   #"returns" message but doesn't display it
   screen_text = font.render(msg, True, color)
   gameDisplay.blit(screen_text, [display_width/2, display_height/2])
   pygame.display.update()
 
   time.sleep(2)
 
   gameLoop()

def text_objects(text, font):
    textSurface = font.render(text, True, black)
    return textSurface, textSurface.get_rect()
 
def button(msg,x,y,w,h,offColor,onColor,action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    #print(click)
    if x+w > mouse[0] > x and y+h > mouse[1] > y:
        pygame.draw.rect(gameDisplay, onColor,(x,y,w,h))

        if click[0] == 1 and action != None:
            action()         
    else:
        pygame.draw.rect(gameDisplay, offColor,(x,y,w,h))

    smallText = pygame.font.SysFont("freesansbold.ttf",20)
    textSurf, textRect = text_objects(msg, smallText)
    textRect.center = ( (x+(w/2)), (y+(h/2)) )
    gameDisplay.blit(textSurf, textRect)

def popup():

    #window = Tkinter.Tk()
    window.wm_withdraw()

    glug = tkMessageBox.showinfo(title="Instructions", message="Poker is a family of gambling card games, but is often considered a skill based game. All poker variants involve betting as an intrinsic part of play, and determine the winner of each hand according to the combinations of players' cards, at least some of which remain hidden until the end of the hand. Poker games vary in the number of cards dealt, the number of shared or community cards, the number of cards that remain hidden, and the betting procedures.\n In most modern poker games, the first round of betting begins with one or more of the players making some form of a forced bet (the blind and/or ante). In standard poker, each player bets according to the rank he believes his hand is worth as compared to the other players. The action then proceeds clockwise as each player in turn must either match, or call, the maximum previous bet or fold, losing the amount bet so far and all further interest in the hand. A player who matches a bet may also raise, or increase the bet. The betting round ends when all players have either called the last bet or folded. If all but one player folds on any round, the remaining player collects the pot without being required to reveal their hand. If more than one player remains in contention after the final betting round, a showdown takes place where the hands are revealed, and the player with the winning hand takes the pot.\nWith the exception of initial forced bets, money is only placed into the pot voluntarily by a player who either believes the bet has positive expected value or who is trying to bluff other players for various strategic reasons. Thus, while the outcome of any particular hand significantly involves chance, the long-run expectations of the players are determined by their actions chosen on the basis of probability, psychology, and game theory.")
    
    
def hands():
   BackGround = gui.Background('poker_hands.png', [0,0])
   screen.fill([255, 255, 255])
   screen.blit(BackGround.image, BackGround.rect)

def gameLoop():
        
        
		BackGround = gui.Background('poker_background.png', [0,0])
		gameExit = False
		#Ends the current game but not the entire program
		gameOver = False
		gameDisplay.fill(white)
		pygame.display.update()
		
		 
		# blit txtbx on the sceen
		
		#username = raw_input("Please enter your username. ")
		#storage = open('usernames.txt', 'wb')
		#pickle.dump(username, storage)

		deck = cardsanddeck.Deck()
                net = gui.netprofits()
		mycards = cardsanddeck.Deck.dealPlayer1(deck)
		p2cards = cardsanddeck.Deck.dealPlayer2(deck)
		p3cards = cardsanddeck.Deck.dealPlayer3(deck)
		p4cards = cardsanddeck.Deck.dealPlayer4(deck)
		p5cards = cardsanddeck.Deck.dealPlayer5(deck)
		mycard1 = mycards[0] + mycards[1]
		mycard2 = mycards[2] + mycards[3]
		p2card1 = p2cards[0] + p2cards[1]
		p2card2 = p2cards[2] + p2cards[3]
		p3card1 = p3cards[0] + p3cards[1]
		p3card2 = p3cards[2] + p3cards[3]
		p4card1 = p4cards[0] + p4cards[1]
		p4card2 = p4cards[2] + p4cards[3]
		p5card1 = p5cards[0] + p5cards[1]
		p5card2 = p5cards[2] + p5cards[3]


		print(mycard1, "HOPPO")
		#Creates the image for the user's hand
		
		#Creates the image for the AI's hands
		p2image1 = gui.Background.nameConvert(BackGround,str(p2card1))
		p2image2 = gui.Background.nameConvert(BackGround,str(p2card2))
		p3image1 = gui.Background.nameConvert(BackGround,str(p3card1))
		p3image2 = gui.Background.nameConvert(BackGround,str(p3card2))
		p4image1 = gui.Background.nameConvert(BackGround,str(p4card1))
		p4image2 = gui.Background.nameConvert(BackGround,str(p4card2))
		p5image1 = gui.Background.nameConvert(BackGround,str(p5card1))
		p5image2 = gui.Background.nameConvert(BackGround,str(p5card2))
		showback = 'back'
		cardofback = gui.Background.nameConvert(BackGround,str(showback))

		print(image1)
		createflop = cardsanddeck.Deck.dealFlop(deck)
		flop = cardsanddeck.Deck.flopList(deck)
		#flop_firstcard = cardsanddeck.Deck.dealFlop(deck)
		flop_firstcard = gui.Background.nameConvert(BackGround,str(flop[0]))
		flop_secondcard = gui.Background.nameConvert(BackGround,str(flop[1]))
		flop_thirdcard = gui.Background.nameConvert(BackGround,str(flop[2]))

                turn_card = cardsanddeck.Deck.dealTurn(deck)
                river_card = cardsanddeck.Deck.dealRiver(deck)
                turn_first_card = gui.Background.nameConvert(BackGround,str(turn_card))
                river_first_card = gui.Background.nameConvert(BackGround,str(river_card))
		while not gameExit:
		    #These two lines implement the background
		    screen.fill([255, 255, 255])
		    screen.blit(BackGround.image, BackGround.rect)


		    cardback = pygame.transform.scale(cardofback, (75,116))
                    cardback_community = pygame.transform.scale(cardofback, (85,123))


		    #This transforms the first hand card image to the proper size, and then implements it into the bottom corner.
		    new_image_file = pygame.transform.scale(image1, (100,145))
		    gameDisplay.blit(new_image_file, [(display_width - 100),(display_height - 145)])
		    #This transforms the second hand card, puts it next to the first card
		    new_image_file2 = pygame.transform.scale(image2, (100,145))
		    gameDisplay.blit(new_image_file2, [(display_width - 200),(display_height - 145)])
		    #This transforms the first flop card and puts it in the center of the table
		    flop_firstcard_image = pygame.transform.scale(flop_firstcard, (85, 123))
		    gameDisplay.blit(flop_firstcard_image,[(display_width/2)-200,(display_height/2)])
		    gameDisplay.blit(cardback_community, [(display_width/2)-200,(display_height/2)])
		    #Second flop card
		    flop_secondcard_image = pygame.transform.scale(flop_secondcard, (85, 123))
		    gameDisplay.blit(flop_secondcard_image,[(display_width/2)-100,(display_height/2)])
		    gameDisplay.blit(cardback_community, [(display_width/2)-100,(display_height/2)])
		    #Third flop card
		    flop_thirdcard_image = pygame.transform.scale(flop_thirdcard, (85, 123))
		    gameDisplay.blit(flop_thirdcard_image,[(display_width/2)-300,(display_height/2)])
		    gameDisplay.blit(cardback_community, [(display_width/2)-300,(display_height/2)])
		    #Player 2's hand
		    p2image_file = pygame.transform.scale(p2image1, (75,116))
		    gameDisplay.blit(p2image_file, [((display_width)-(display_width - 1)),(display_height/3)])
		    
		    gameDisplay.blit(cardback, [((display_width)-(display_width - 1)),(display_height/3)])
		    p2image_file2 = pygame.transform.scale(p2image2, (75,116))
		    gameDisplay.blit(p2image_file2, [(75),(display_height/3)])
		    gameDisplay.blit(cardback, [(75),(display_height/3)])
		    #Player 3's hand
		    p3image_file = pygame.transform.scale(p3image1, (75,116))
		    gameDisplay.blit(p3image_file, [(175),(display_height - (display_height - 1))])
		    gameDisplay.blit(cardback, [(175),(display_height - (display_height - 1))])

		    p3image_file2 = pygame.transform.scale(p3image2, (75,116))
		    gameDisplay.blit(p3image_file2, [(100),(display_height - (display_height - 1))])
		    gameDisplay.blit(cardback, [(100),(display_height - (display_height - 1))])
		    #Player 4's hand
		    p4image_file = pygame.transform.scale(p4image1, (75,116))
		    gameDisplay.blit(p4image_file, [(display_width - 275),(display_height - (display_height - 1))])
		    gameDisplay.blit(cardback, [(display_width - 275),(display_height - (display_height - 1))])

		    p4image_file2 = pygame.transform.scale(p4image2, (75,116))
		    gameDisplay.blit(p4image_file2, [(display_width - 200),(display_height - (display_height - 1))])
		    gameDisplay.blit(cardback, [(display_width - 200),(display_height - (display_height - 1))])
		    #Player 5's hand
		    p5image_file = pygame.transform.scale(p5image1, (75,116))
		    gameDisplay.blit(p5image_file, [(display_width - 175),(display_height/3)])
		    gameDisplay.blit(cardback, [(display_width - 175),(display_height/3)])

		    p5image_file2 = pygame.transform.scale(p5image2, (75,116))
		    gameDisplay.blit(p5image_file2, [(display_width - 100),(display_height/3)])
		    gameDisplay.blit(cardback, [(display_width - 100),(display_height/3)])
		    

                    
                    turn_image = pygame.transform.scale(turn_first_card, (85,123))
		    gameDisplay.blit(turn_image,[(display_width/2),(display_height/2)])
                    gameDisplay.blit(cardback_community, [(display_width/2),(display_height/2)])

                    river_image = pygame.transform.scale(river_first_card, (85,123))
		    gameDisplay.blit(river_image,[(display_width/2)+100,(display_height/2)])
                    gameDisplay.blit(cardback_community, [(display_width/2)+100,(display_height/2)])
		    #new_image_file2 = pygame.transform.scale(image2, (75,116))
		    #gameDisplay.blit(new_image_file2, [(display_width - 200),(display_height - 145)])




		   #These define what the buttons are in the bottom left, what they do, and what color they are with the mouse on and off
		    button("Call/Check",2 * display_width/20,(4.5 * display_height)/5,100,50,green,bright_green,Background.call())
		    button("Raise2BB",(4 * display_width)/20,(4.5 * display_height)/5,100,50,green,bright_green,Background.raise2bb())
		    button("Fold",(display_width)-(display_width - 1),(4.5 * display_height)/5,100,50,red,bright_red,Background.fold())
		    #button("Check",(2 * display_width)/20,(4.5 * display_height)/5,100,50,green,bright_red,popup)
	      

		    pygame.display.update()
		    #This while loop is for once the player loses.
		    while gameOver == True:
		         gameDisplay.fill(black)
		         message_to_screen("Game Over! Press C to play again or Q to quit.", red)
		         pygame.display.update()
		         #This tells the computer what to do if C or Q is pressed
		        
		    #Allows the events to happen while the game isn't exited
		    for event in pygame.event.get():
		       #Tells you every event that happens in the command prompt. VERY ANNOYING
		       #print(event)
		       #This loop allows you to actually quit the game. Good!
		       if event.type == pygame.QUIT:
			  gameExit = True
		       #If a key is pressed
		    #gui.netprofits.stashcheck(net)
		pygame.display.update()
		clock.tick(60)
mama = gui.Menu('goodold.jpg', gameDisplay, display_width, display_height, gameLoop)
mama
gameLoop()
pygame.quit()
quit()

